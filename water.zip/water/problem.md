# 一、semi 
    'semi': 0,//加分号，和不加分号都可以。
    'semi': ['error','always'];//必须要分号。
    'semi': ['error','never'];//不要分号。
    错误的格式，都可以在.eslintrc.js的rules中设置相应的格式为0，那么就是可以不用理会这个格式的错误。
# 二、绑定style 
    :style="{height:waterHeightRight+'px'}"