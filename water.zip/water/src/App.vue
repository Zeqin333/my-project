<template>
  <div id="app">
    <water></water>
  </div>
</template>

<script type="text/ecmascript-6">
import water from 'components/water/water';

export default {
  name: 'app',
  components: {
    water
  }
};
</script>

